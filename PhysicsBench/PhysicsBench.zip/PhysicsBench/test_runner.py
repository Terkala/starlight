import csv
from contextlib import contextmanager
import json
from pathlib import Path
import shutil
import uuid
import unittest
from unittest.mock import patch

import run as bench


@contextmanager
def temporary():
    base = bench.BUNDLE / "results" / "runner-tests"
    base.mkdir(parents=True, exist_ok=True)
    directory = base / uuid.uuid4().hex
    directory.mkdir()
    try:
        yield directory
    finally:
        directory.resolve().relative_to(base.resolve())
        shutil.rmtree(directory)



class RunnerTests(unittest.TestCase):
    def layout(self, root):
        repo = root / "repo"
        (repo / "Content.IntegrationTests").mkdir(parents=True)
        (repo / "Content.IntegrationTests/Content.IntegrationTests.csproj").write_text("<Project/>")
        (repo / "RobustToolbox/Robust.Shared").mkdir(parents=True)
        (repo / "RobustToolbox/Robust.Shared/Robust.Shared.csproj").write_text("<Project/>")
        output = root / "output"
        output.mkdir()
        payload = root / "payload"
        payload.mkdir()
        (payload / "Test.cs.txt").write_text("// temporary source\n")
        hook = repo / bench.HOOK
        hook.parent.mkdir(parents=True)
        hook.write_bytes(b"\xef\xbb\xbfinternal static void Apply()\r\n{\r\n    Original();\r\n}\r\n")
        return repo, output, payload, hook

    def test_install_recover_preserves_original_bytes_and_user_sources(self):
        with temporary() as directory:
            repo, output, payload, hook = self.layout(Path(directory))
            original = hook.read_bytes()
            keep = repo / "Content.IntegrationTests/UserWork.cs"
            keep.write_text("user work")
            installation = bench.Installation(repo, output, payload).install()
            self.assertIn(b"SL_PORTABLE_PHYSICS_BENCH", hook.read_bytes())
            self.assertTrue((repo / "Content.IntegrationTests" / bench.GENERATED / "Test.cs").exists())
            recovered = bench.Installation(repo, output, payload)
            recovered.state = json.loads(installation.journal.read_text())
            recovered.restore()
            self.assertEqual(hook.read_bytes(), original)
            self.assertEqual(keep.read_text(), "user work")
            self.assertFalse((repo / "Content.IntegrationTests" / bench.GENERATED).exists())

    def test_concurrent_edit_is_preserved_and_backup_retained(self):
        with temporary() as directory:
            repo, output, payload, hook = self.layout(Path(directory))
            installation = bench.Installation(repo, output, payload).install()
            hook.write_bytes(b"user changed this during measurement")
            with self.assertRaisesRegex(RuntimeError, "preserved"):
                installation.restore()
            self.assertEqual(hook.read_bytes(), b"user changed this during measurement")
            self.assertFalse(installation.state["restored"])
            self.assertTrue((output / "backup-1.bin").exists())

    def test_failed_install_rolls_back_generated_files(self):
        with temporary() as directory:
            repo, output, payload, hook = self.layout(Path(directory))
            hook.write_text("incompatible profiler")
            installation = bench.Installation(repo, output, payload)
            with self.assertRaisesRegex(RuntimeError, "signature changed"):
                installation.install()
            installation.restore()
            self.assertFalse((repo / "Content.IntegrationTests" / bench.GENERATED).exists())
            self.assertEqual(hook.read_text(), "incompatible profiler")

    def test_build_failure_exports_failure_and_restores_sources(self):
        with temporary() as directory:
            repo, output, _, hook = self.layout(Path(directory))
            original = hook.read_bytes()
            fake_revision = {"head": "abc", "tracked_patch_sha256": "def", "tracked_status": ""}
            with patch.object(bench.shutil, "which", return_value="present"), \
                 patch.object(bench, "revision", return_value=fake_revision), \
                 patch.object(bench.subprocess, "check_output", return_value="10.0.100"), \
                 patch.object(bench, "execute", return_value=7):
                code = bench.main(["--repo", str(repo), "--output", str(output), "--cases", "round_contacts"])
            self.assertEqual(code, 1)
            status = json.loads((output / "run-status.json").read_text())
            self.assertEqual(status["exit_code"], 1)
            self.assertTrue(status["source_restored"])
            with (output / "results.csv").open(encoding="utf-8-sig", newline="") as stream:
                rows = list(csv.DictReader(stream))
            self.assertEqual(rows[0]["status"], "build_failed")
            self.assertEqual(rows[0]["PreSolve_ms"], "")
            self.assertEqual(hook.read_bytes(), original)
            self.assertFalse((repo / "Content.IntegrationTests/.portable-physics-bench.lock").exists())


if __name__ == "__main__":
    unittest.main()
