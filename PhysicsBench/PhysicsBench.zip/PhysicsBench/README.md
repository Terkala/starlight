# Portable physics benchmark

Copy this entire **PhysicsBench** folder anywhere inside a compatible Starlight
**source repository**, then run:

```powershell
python PhysicsBench/run.py
```

Or, from inside the copied folder: `python run.py`.
Python 3.10+ with its standard library is sufficient. Git, the repository's .NET SDK, initialized
engine submodules, and the normal project/NuGet dependencies must already be
available. This cannot run against only a deployed server's compiled files.
The runner uses the current local content AND engine working copies, including
local patches; it does not fetch, switch branches, or change production code.

The default runs all three cases with **1,000 equipped humans**, 20 Hz, the
**server light tree off**, and **method probes off**. Each case has seven stages,
each with 100 settling ticks and 300 measured ticks. Each case/repetition gets a
fresh test process. Builds use Release and include project references, so a patch
to the engine or content is rebuilt. Compiler analyzers are disabled; source
generators still run. Existing Starlight per-event profiling is temporarily guarded.

The terminal prints the output directory. Its **results.csv** has 21 rows for a
successful default run: one per case/stage. It includes:

* Whole server tick mean, median, p95, and all eight physics phase means in **ms**.
* Phase percentages and phase sum. The sum is not the entire server tick.
* Actual awake population, commanded movers, contacts/touching contacts, distance,
  living/movable humans, oxygen, and diagnostic status.
* Content/engine commits, tracked working-diff hashes, payload/assembly hashes,
  and paths to raw reports and logs. The manifest also records SDK and host details.

Raw JSON contains stage-level method timings when enabled. Frame CSVs and logs
are retained, including on failure. **Only compare rows whose status is passed**,
with matched settings, movement distances and population/contact counts. Failed
or missing measurements are not replaced with zero. The program exits nonzero
if a test/build fails, sources change during execution, or cleanup conflicts.

## Cases

* `round_contacts`: stationary humans; repeatedly add/delete four soft sensors
  and four ordinary loose tools per human. Checks for contacts referencing deleted
  workload entities and duplicate fixture/child pairs.
* `round_movement`: stationary baseline, then alternate moving with eight extra
  directly parented tools per human and moving after deleting them. Human-to-human
  collisions are forbidden. Stages 2/4/6 are moving controls, not idle controls.
* `round_presolve`: idle, one third moving, idle, two thirds blocked by individual
  walls, idle, all moving, idle. This varies active input at a fixed registered
  population; it does not simulate NPC AI or player networking.

All humans have a uniform, backpack, and held crowbar. Grid air is explicitly
filled before spawning them. Stage assertions check survival, oxygen, movement
permissions, actual movement, and active population. Ordinary gameplay systems
remain enabled. Direct parenting deliberately exaggerates transform work; it is
not a model of a normal inventory's exact cost.

## Options

```powershell
# Quick functional check (not a performance baseline):
python PhysicsBench/run.py --bodies 16 --ticks 40 --warmup 60
# A different local checkout:
python PhysicsBench/run.py --repo D:\src\starlight
# More reproducibility, fresh process per case/repetition:
python PhysicsBench/run.py --repeat 3
# Focused case, custom output directory (must be empty or new):
python PhysicsBench/run.py --cases round_movement --output D:\benchmarks\patch-a
# Already restored dependencies, avoid a network restore:
python PhysicsBench/run.py --no-restore
# Additional method profiling; do not mix these timings with ordinary runs:
python PhysicsBench/run.py --probes
```

Run the same command on each patch and compare CSV stage rows. Do not edit the
repository, switch branches, or run builds/other benchmarks during measurement.
Compare repeated runs on the same host; these results cannot establish a live
server's CPU multiplier from hardware/population differences alone.

## Temporary installation and recovery

The folder contains the C# payload and executor; it does not depend on the earlier
physics test files or modifications to PoolManagerTestEventHandler/SystemTimingPatch.
It temporarily installs `Content.IntegrationTests/PortablePhysicsBench.Generated/`.
If present, it temporarily guards the existing EventTimingSummaryPatch.Apply().
Original bytes are backed up and restored on success, failure, or Ctrl+C. Unknown
files and edits made during a run are preserved rather than overwritten.

The output contains an installation journal. After power loss or forced process
termination, ensure the old benchmark process has stopped, then run:

```powershell
python PhysicsBench/run.py --recover PATH\TO\RESULTS\installation.json
```

A repository lock prevents simultaneous installs. Do not delete the journal or
backups until recovery succeeds. Normal completion leaves compiled benchmark
binaries and ordinary build outputs; source changes are restored. The payload is
opt-in and will not run through ordinary test discovery without the executor.

Compatibility targets the Starlight APIs used by this suite, not arbitrary SS14
forks or future API-breaking changes. Unsupported APIs fail the build/test with
logs, rather than silently skipping a case. No PowerShell executor, existing test
patch, downloaded server build, or Grafana export is required.

Runner checks: `python -m unittest discover -s PhysicsBench -p "test_*.py"`.

Validated against content `bf595642` / engine `556943b7` with the earlier benchmark
helpers removed: all three standalone cases passed at 16 humans, exporting 21
stage rows and restoring the original test sources byte-for-byte. The workloads
derive from the full-scale 1,000-human experiments; the portable packaging check
is a functional check rather than another performance baseline.
