#!/usr/bin/env python3
"""Drop this folder into a compatible Starlight source checkout; run python run.py.

No Python packages or PowerShell are required. See README.md for prerequisites.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import signal
import subprocess
import sys
import time
import uuid

CASES = ("round_contacts", "round_movement", "round_presolve")
PHASES = ("PreSolve", "Broadphase", "Collide", "BuildIslands", "SolveIslands",
          "UpdateBodies", "Cleanup", "PostSolve")
GENERATED = "PortablePhysicsBench.Generated"
HOOK = "Content.IntegrationTests/_Starlight/Patches/EventTimingSummaryPatch.cs"
BUNDLE = Path(__file__).resolve().parent


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def atomic_json(path: Path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def repo_root(explicit: Path | None) -> Path:
    candidates = [explicit.resolve()] if explicit else list(BUNDLE.parents) + [Path.cwd(), *Path.cwd().parents]
    for path in candidates:
        if (path / "Content.IntegrationTests/Content.IntegrationTests.csproj").is_file():
            return path
    raise RuntimeError("Source repository not found. Use --repo PATH to the source checkout, not a compiled server installation.")


def git(repo: Path, *args) -> str:
    result = subprocess.run(["git", "-C", str(repo), *args], capture_output=True, check=True)
    return result.stdout.decode("utf-8", errors="replace").strip()


def revision(repo: Path):
    patch = subprocess.run(["git", "-C", str(repo), "diff", "HEAD", "--binary"], capture_output=True, check=True).stdout
    return {"head": git(repo, "rev-parse", "HEAD"), "tracked_patch_sha256": digest(patch),
            "tracked_status": git(repo, "status", "--short", "--untracked-files=no")}


class Installation:
    """Write-ahead recovery journal; restore only files we still own byte-for-byte."""
    def __init__(self, repo: Path, output: Path, payload: Path):
        self.repo, self.output, self.payload = repo, output, payload
        self.journal = output / "installation.json"
        self.state = {"repo": str(repo), "restored": False, "changes": []}

    def write(self, path: Path, data: bytes):
        old = path.read_bytes() if path.exists() else None
        if old == data:
            return
        backup = None
        if old is not None:
            backup = self.output / f"backup-{len(self.state['changes'])}.bin"
            backup.write_bytes(old)
        change = {"path": str(path), "backup": str(backup) if backup else None,
                  "before_sha256": digest(old) if old is not None else None,
                  "installed_sha256": digest(data)}
        self.state["changes"].append(change)
        atomic_json(self.journal, self.state)  # Journal before mutation.
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)

    def install(self):
        target = self.repo / "Content.IntegrationTests" / GENERATED
        if target.exists():
            raise RuntimeError(f"Reserved generated directory already exists: {target}. Recover the previous run first.")
        for source in sorted(self.payload.glob("*.cs.txt")):
            self.write(target / source.name.removesuffix(".txt"), source.read_bytes())
        hook = self.repo / HOOK
        if hook.exists():
            raw = hook.read_bytes()
            text = raw.decode("utf-8-sig")
            matches = list(re.finditer(r"\b(?:internal|public|private)\s+static\s+void\s+Apply\s*\(\s*\)\s*\{", text))
            if len(matches) != 1:
                raise RuntimeError("Cannot safely disable the existing per-event profiler: Apply() signature changed")
            point = matches[0].end()
            guard = '\n        // Temporary portable benchmark guard.\n        if (System.Environment.GetEnvironmentVariable("SL_PORTABLE_PHYSICS_BENCH") == "1") return;\n'
            encoding = "utf-8-sig" if raw.startswith(b"\xef\xbb\xbf") else "utf-8"
            self.write(hook, (text[:point] + guard + text[point:]).encode(encoding))
        return self

    def restore(self):
        conflicts = []
        for change in reversed(self.state["changes"]):
            path = Path(change["path"])
            current = path.read_bytes() if path.exists() else None
            current_hash = digest(current) if current is not None else None
            if current_hash == change["before_sha256"]:
                continue  # Already restored, or journal was written before the mutation.
            if current_hash != change["installed_sha256"]:
                conflicts.append(str(path))
                continue
            if change["backup"]:
                path.write_bytes(Path(change["backup"]).read_bytes())
            else:
                path.unlink()
        directory = self.repo / "Content.IntegrationTests" / GENERATED
        if directory.exists() and not any(directory.iterdir()):
            directory.rmdir()
        self.state["restored"] = not conflicts
        self.state["conflicts"] = conflicts
        atomic_json(self.journal, self.state)
        if conflicts:
            raise RuntimeError("Files changed during the run; preserved those edits. Backups/journal: " + str(self.journal))


def terminate(process):
    if process.poll() is not None:
        return
    if os.name == "nt":
        subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"], capture_output=True)
    else:
        os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()


def execute(command, repo: Path, environment, log: Path, timeout: int):
    print("Running:", subprocess.list2cmdline([str(v) for v in command]), flush=True)
    print("Log:", log, flush=True)
    options = {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {"start_new_session": True}
    with log.open("wb") as stream:
        process = subprocess.Popen([str(v) for v in command], cwd=repo, env=environment,
                                   stdout=stream, stderr=subprocess.STDOUT, **options)
        start = time.monotonic()
        try:
            while True:
                try:
                    return process.wait(timeout=min(60, max(1, timeout - (time.monotonic() - start))))
                except subprocess.TimeoutExpired:
                    elapsed = time.monotonic() - start
                    if elapsed >= timeout:
                        terminate(process)
                        raise RuntimeError(f"Timed out after {timeout}s; see {log}")
                    print(f"  still running ({elapsed:.0f}s); {log.name}", flush=True)
        except BaseException:
            terminate(process)
            raise


def export_csv(output: Path, records, metadata):
    fields = ["run", "repetition", "scenario", "status", "error", "stage", "state", "bodies",
              "ticks_per_stage", "warmup_ticks", "light_tree", "method_probes", "commanded_movers",
              "alive", "can_move", "minimum_oxygen_moles", "tail_awake", "tail_contacts", "tail_touching",
              "tail_hard_touching", "temporary_entities", "distance", "max_cross_actor_contacts",
              "max_retired_workload_contacts", "duplicate_contact_keys", "tick_mean_ms", "tick_p50_ms", "tick_p95_ms",
              "phase_sum_ms", *[p + "_ms" for p in PHASES], *[p + "_percent" for p in PHASES],
              "content_commit", "engine_commit", "content_patch_sha256", "engine_patch_sha256",
              "content_assembly_sha256", "engine_assembly_sha256", "harness_assembly_sha256", "payload_sha256",
              "report", "log"]
    rows = []
    for record in records:
        base = {"run": metadata["run"], "repetition": record["repetition"], "scenario": record["scenario"],
                "status": record["status"], "error": record.get("error", ""), "report": record.get("report", ""),
                "log": record.get("log", ""), "content_commit": metadata["content"]["head"],
                "engine_commit": metadata["engine"]["head"], "content_patch_sha256": metadata["content"]["tracked_patch_sha256"],
                "engine_patch_sha256": metadata["engine"]["tracked_patch_sha256"], "payload_sha256": metadata["payload_sha256"]}
        report = record.get("data")
        if report is None:
            rows.append(base)
            continue
        base.update(bodies=report["count"], ticks_per_stage=report["ticks"], warmup_ticks=report["warmup"],
                    light_tree=report["lightTreeEnabled"], method_probes=report["probesEnabled"],
                    duplicate_contact_keys=report["duplicate_contact_keys"],
                    content_assembly_sha256=report["content_sha256"], engine_assembly_sha256=report["engine_sha256"],
                    harness_assembly_sha256=report["harness_sha256"])
        for stage in report["stages"]:
            row = {**base}
            for field in ("stage", "state", "commanded_movers", "alive", "tail_awake", "tail_contacts", "tail_touching",
                          "tail_hard_touching", "temporary_entities", "distance", "max_cross_actor_contacts",
                          "max_retired_workload_contacts", "tick_mean_ms", "tick_p50_ms", "tick_p95_ms"):
                row[field] = stage[field]
            row["can_move"], row["minimum_oxygen_moles"] = stage["canMove"], stage["minimumOxygen"]
            total = sum(stage["phase_mean_ms"].values())
            row["phase_sum_ms"] = total
            for phase in PHASES:
                row[phase + "_ms"] = stage["phase_mean_ms"][phase]
                row[phase + "_percent"] = stage["phase_mean_ms"][phase] * 100 / total if total else ""
            rows.append(row)
        if not report["stages"]:
            rows.append(base)
    temporary = output / "results.csv.tmp"
    with temporary.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    temporary.replace(output / "results.csv")


def validate_report(report, case, args):
    errors = []
    if report.get("schema") != 3:
        return ["Unsupported or stale report schema"]
    if report["scenario"] != case or report["count"] != args.bodies or report["ticks"] != args.ticks or report["warmup"] != args.warmup:
        errors.append("Report workload does not match invocation")
    if report["lightTreeEnabled"] or report["probesEnabled"] != args.probes:
        errors.append("Unexpected lighting/probe configuration")
    if len(report["stages"]) != 7 or report["measured_ticks"] != 7 * args.ticks:
        errors.append("Incomplete stage/tick count")
    if report["duplicate_contact_keys"]:
        errors.append("Duplicate contacts detected")
    errors.extend(report["stageFailures"])
    for stage in report["stages"]:
        if set(stage["phase_mean_ms"]) != set(PHASES):
            errors.append("Missing physics phase")
        if stage["alive"] != args.bodies or stage["canMove"] != args.bodies or stage["minimumOxygen"] <= 10:
            errors.append("Population/atmosphere validation failed")
    return errors


def arguments(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, help="Source checkout; default searches parent directories")
    parser.add_argument("--bodies", type=int, default=1000)
    parser.add_argument("--ticks", type=int, default=300, help="Measured ticks PER stage")
    parser.add_argument("--warmup", type=int, default=100, help="Settling ticks PER stage")
    parser.add_argument("--cases", nargs="+", choices=CASES, default=list(CASES))
    parser.add_argument("--repeat", type=int, default=1)
    parser.add_argument("--probes", action="store_true", help="Extra method timers; distorts performance, off by default")
    parser.add_argument("--no-restore", action="store_true", help="Use an already restored NuGet graph")
    parser.add_argument("--output", type=Path, help="New, empty output directory; default PhysicsBench/results/<run>")
    parser.add_argument("--timeout-minutes", type=int, default=45)
    parser.add_argument("--recover", type=Path, metavar="INSTALLATION_JSON", help="Restore a run interrupted by power loss/forced termination")
    args = parser.parse_args(argv)
    if not (16 <= args.bodies <= 5000 and 40 <= args.ticks <= 3000 and 60 <= args.warmup <= 1000 and 1 <= args.repeat <= 100 and 1 <= args.timeout_minutes <= 45):
        parser.error("Require bodies 16..5000, ticks 40..3000, warmup 60..1000, repeat 1..100, timeout 1..45 minutes")
    if len(set(args.cases)) != len(args.cases):
        parser.error("Duplicate cases are not allowed; use --repeat")
    return args


def main(argv=None):
    args = arguments(argv)
    if args.recover:
        state = json.loads(args.recover.read_text(encoding="utf-8"))
        install = Installation(Path(state["repo"]), args.recover.resolve().parent, BUNDLE / "payload")
        install.state = state
        install.restore()
        lock = install.repo / "Content.IntegrationTests/.portable-physics-bench.lock"
        if lock.exists() and json.loads(lock.read_text())["journal"] == str(install.journal): lock.unlink()
        print("Recovered:", install.repo)
        return 0
    if not shutil.which("dotnet") or not shutil.which("git"):
        raise RuntimeError("Install the repository's .NET SDK and Git, and put both on PATH")
    repo = repo_root(args.repo)
    if not (repo / "RobustToolbox/Robust.Shared/Robust.Shared.csproj").is_file():
        raise RuntimeError("Initialize the repository's RobustToolbox submodule before running")
    run = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8]
    output = (args.output or BUNDLE / "results" / run).resolve()
    if output.exists() and any(output.iterdir()):
        raise RuntimeError(f"Refusing to reuse a nonempty output directory: {output}")
    output.mkdir(parents=True, exist_ok=True)
    install = Installation(repo, output, BUNDLE / "payload")
    lock = repo / "Content.IntegrationTests/.portable-physics-bench.lock"
    try:
        with lock.open("x", encoding="utf-8") as stream:
            json.dump({"pid": os.getpid(), "journal": str(install.journal)}, stream)
    except FileExistsError:
        raise RuntimeError(f"Another run or interrupted installation exists: {lock}. See README recovery instructions.")
    records = []
    metadata = None
    exit_code = 0
    try:
        payload_hashes = {p.name: digest(p.read_bytes()) for p in sorted((BUNDLE / "payload").glob("*.cs.txt"))}
        if len(payload_hashes) != 4:
            raise RuntimeError("Bundle must contain four C# payload files")
        metadata = {"schema": 1, "run": run, "repo": str(repo), "settings": vars(args).copy(),
                    "content": revision(repo), "engine": revision(repo / "RobustToolbox"),
                    "python": sys.version, "platform": platform.platform(), "processor": platform.processor(),
                    "logical_cpus": os.cpu_count(), "dotnet_sdk": subprocess.check_output(["dotnet", "--version"], cwd=repo, text=True).strip(),
                    "payload_files": payload_hashes, "payload_sha256": digest(json.dumps(payload_hashes, sort_keys=True).encode())}
        metadata["runner_sha256"] = digest(Path(__file__).read_bytes())
        metadata["settings"] = {k: str(v) if isinstance(v, Path) else v for k, v in metadata["settings"].items()}
        atomic_json(output / "manifest.json", metadata)
        install.install()
        environment = os.environ.copy()
        environment.update(SL_PORTABLE_PHYSICS_BENCH="1", SL_PHYSICS_STRESS="1", DOTNET_TieredCompilation="0",
                           SL_PHYSICS_STRESS_BODIES=str(args.bodies), SL_PHYSICS_STRESS_TICKS=str(args.ticks),
                           SL_PHYSICS_STRESS_WARMUP=str(args.warmup), SL_PHYSICS_STRESS_PROBES="1" if args.probes else "0",
                           SL_PHYSICS_STRESS_LIGHT_TREE="false", SL_PHYSICS_STRESS_ENGINE=metadata["engine"]["head"],
                           SL_PHYSICS_STRESS_OUTPUT=str(output))
        command = ["dotnet", "build", "Content.IntegrationTests/Content.IntegrationTests.csproj", "-c", "Release", "-m:1",
                   "-p:TreatWarningsAsErrors=false", "-p:RunAnalyzers=false"]
        if args.no_restore: command.append("--no-restore")
        code = execute(command, repo, environment, output / "build.log", 1800)
        if code:
            exit_code = 1
            records.extend({"scenario": c, "repetition": 1, "status": "build_failed", "error": f"Build exit {code}", "log": str(output / "build.log")} for c in args.cases)
            return 1
        executable = repo / "bin/Content.IntegrationTests/Content.IntegrationTests.exe"
        host = [str(executable)] if os.name == "nt" else ["dotnet", str(executable.with_suffix(".dll"))]
        for repetition in range(1, args.repeat + 1):
            for case in args.cases:
                name = f"{run}-r{repetition}"
                report_path = output / f"{name}-{case}.json"
                log = output / f"r{repetition}-{case}.log"
                record = {"scenario": case, "repetition": repetition, "status": "failed", "report": str(report_path), "log": str(log)}
                records.append(record)
                environment.update(SL_PHYSICS_STRESS_CASES=case, SL_PHYSICS_STRESS_RUN=name)
                print(f"\n{case}, repetition {repetition}/{args.repeat}, {args.bodies} humans", flush=True)
                try:
                    code = execute([*host, "--filter", "FullyQualifiedName~PortablePhysicsBenchTest", "--show-stdout", "All",
                                    "--output", "Detailed", "--progress", "off", "--timeout", f"{args.timeout_minutes}m"],
                                   repo, environment, log, args.timeout_minutes * 60 + 30)
                    if not report_path.exists(): raise RuntimeError(f"No report produced (test exit {code})")
                    report = json.loads(report_path.read_text(encoding="utf-8-sig"))
                    if report.get("schema") != 3: raise RuntimeError("Unsupported report schema")
                    errors = validate_report(report, case, args)
                    if code: errors.insert(0, f"Test process exit {code}")
                    record.update(data=report, status="failed" if errors else "passed", error="; ".join(errors))
                except KeyboardInterrupt:
                    record["error"] = "Interrupted by user"
                    if report_path.exists():
                        try:
                            partial = json.loads(report_path.read_text(encoding="utf-8-sig"))
                            validate_report(partial, case, args)
                            record["data"] = partial
                        except (ValueError, KeyError, TypeError):
                            pass
                    raise
                except Exception as error:
                    record["error"] = str(error)
                if record["status"] != "passed": exit_code = 1
                export_csv(output, records, metadata)
                print("Result:", record["status"], record.get("error", ""), flush=True)
    except BaseException as error:
        exit_code = 130 if isinstance(error, KeyboardInterrupt) else 1
        if not records:
            records.extend({"scenario": c, "repetition": 1, "status": "setup_failed", "error": str(error)} for c in args.cases)
        print(f"ERROR: {error}", file=sys.stderr)
    finally:
        try:
            install.restore()
        except Exception as error:
            exit_code = 1
            for record in records:
                record.update(status="cleanup_conflict", error=str(error))
            print(f"RESTORE ERROR: {error}", file=sys.stderr)
        else:
            lock.unlink(missing_ok=True)
        if metadata:
            if install.state["restored"]:
                try:
                    for key, path in (("content", repo), ("engine", repo / "RobustToolbox")):
                        after = revision(path)
                        if any(after[k] != metadata[key][k] for k in ("head", "tracked_patch_sha256")):
                            exit_code = 1
                            for record in records:
                                record.update(status="source_changed", error="Repository changed during the run; timings are not attributable to the original patch")
                except (OSError, subprocess.CalledProcessError) as error:
                    exit_code = 1
                    for record in records:
                        record.update(status="verification_failed", error=str(error))
                    print(f"Cannot verify source restoration: {error}", file=sys.stderr)
            export_csv(output, records, metadata)
            atomic_json(output / "run-status.json", {"exit_code": exit_code, "source_restored": install.state["restored"],
                        "cases": [{k: v for k, v in r.items() if k != "data"} for r in records]})
        print("CSV:" if (output / "results.csv").exists() else "Output directory:",
              output / "results.csv" if (output / "results.csv").exists() else output, flush=True)
    return exit_code


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (RuntimeError, OSError, subprocess.CalledProcessError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        sys.exit(1)
